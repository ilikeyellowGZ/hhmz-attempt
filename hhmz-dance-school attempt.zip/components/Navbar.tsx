import React, { useState, useEffect } from 'react';
import { NavLink } from '../types';
import { Menu, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const links: NavLink[] = [
  { label: 'Story', href: '#story' },
  { label: 'Services', href: '#services' },
  { label: 'Adventures', href: '#adventures' },
  { label: 'Shop', href: '#shop' },
  { label: 'Contact', href: '#contact', isSpecial: true },
];

const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-500 ease-in-out ${
          isScrolled ? 'py-4 bg-black/80 backdrop-blur-md border-b border-white/10' : 'py-8 bg-transparent'
        }`}
      >
        <div className="container mx-auto px-6 md:px-12 flex justify-between items-center">
          {/* Logo */}
          <a href="#" className="flex items-center gap-3 group">
            <div className="w-10 h-10 rounded-full bg-brand-red flex items-center justify-center overflow-hidden border border-white/20 group-hover:scale-110 transition-transform duration-300">
               <img src="https://api.dicebear.com/9.x/icons/svg?seed=HHMZ" alt="Logo" className="w-6 h-6 invert" />
            </div>
            <span className="font-display font-bold text-lg tracking-widest text-white uppercase group-hover:text-brand-red transition-colors">
              HHMZ Dance School
            </span>
          </a>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-8">
            {links.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className={`text-xs font-bold tracking-[0.2em] uppercase transition-all duration-300 relative group ${
                  link.isSpecial ? 'text-brand-red hover:text-white' : 'text-gray-300 hover:text-white'
                }`}
              >
                {link.label}
                <span className={`absolute -bottom-1 left-0 w-0 h-[1px] bg-current transition-all duration-300 group-hover:w-full`} />
              </a>
            ))}
          </div>

          {/* Mobile Toggle */}
          <button
            className="md:hidden text-white hover:text-brand-red transition-colors"
            onClick={() => setMobileMenuOpen(true)}
          >
            <Menu size={28} />
          </button>
        </div>
      </nav>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, x: '100%' }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: '100%' }}
            transition={{ type: "tween", ease: [0.22, 1, 0.36, 1], duration: 0.5 }}
            className="fixed inset-0 z-50 bg-brand-dark flex flex-col items-center justify-center"
          >
            <button
              className="absolute top-8 right-6 text-white hover:text-brand-red"
              onClick={() => setMobileMenuOpen(false)}
            >
              <X size={32} />
            </button>
            <div className="flex flex-col items-center gap-8">
              {links.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`text-2xl font-display font-bold tracking-widest uppercase ${
                    link.isSpecial ? 'text-brand-red' : 'text-white'
                  }`}
                >
                  {link.label}
                </a>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default Navbar;