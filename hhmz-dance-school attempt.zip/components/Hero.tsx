import React from 'react';
import { motion } from 'framer-motion';
import { MoveRight } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section className="relative w-full h-screen overflow-hidden">
      {/* Background Image with slight parallax or zoom effect on load */}
      <div className="absolute inset-0">
        <motion.div 
            initial={{ scale: 1.1 }}
            animate={{ scale: 1 }}
            transition={{ duration: 2.5, ease: [0.22, 1, 0.36, 1] }}
            className="w-full h-full"
        >
            <img
            // Using a specific lively dance image placeholder
            src="https://images.unsplash.com/photo-1547153760-18fc86324498?q=80&w=2574&auto=format&fit=crop"
            alt="Dancers"
            className="w-full h-full object-cover object-center opacity-70"
            />
        </motion.div>
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent" />
      </div>

      {/* Content */}
      <div className="absolute inset-0 flex flex-col justify-end pb-32 container mx-auto px-6 md:px-12">
        <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5, duration: 0.8 }}
            className="max-w-4xl"
        >
            <h2 className="text-brand-red font-bold tracking-widest text-sm mb-4 uppercase">
                 Join the movement
            </h2>
            <h1 className="font-display font-bold text-6xl md:text-8xl lg:text-9xl text-white tracking-tight leading-none mb-6">
            World DS <span className="inline-block text-brand-red align-middle"><MoveRight size={64} strokeWidth={2.5} /></span>
            </h1>
        </motion.div>
      </div>

      {/* Pagination dots simulation */}
      <div className="absolute bottom-10 left-0 right-0 flex justify-center gap-3">
        {[0, 1, 2, 3, 4].map((i) => (
          <div
            key={i}
            className={`w-2 h-2 rounded-full border border-white/50 ${
              i === 2 ? 'bg-white' : 'bg-transparent'
            }`}
          />
        ))}
      </div>
    </section>
  );
};

export default Hero;