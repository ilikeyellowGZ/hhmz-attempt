import React from 'react';

const NoiseOverlay: React.FC = () => {
  return <div className="bg-noise" aria-hidden="true" />;
};

export default NoiseOverlay;