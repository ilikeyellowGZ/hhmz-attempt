import React from 'react';
import { Facebook, Instagram, Youtube, MapPin } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-black text-white py-20 border-t border-white/5 relative z-10">
      <div className="container mx-auto px-6 md:px-12">
        <div className="flex flex-col lg:flex-row gap-12 lg:gap-24">
          
          {/* Left Column: Contact & Nav */}
          <div className="flex-1 flex flex-col justify-between">
            <div>
              <div className="mb-12">
                 <button className="group relative px-8 py-3 border border-brand-red text-white text-xs font-bold tracking-[0.2em] uppercase overflow-hidden">
                    <span className="relative z-10 transition-colors duration-300 group-hover:text-black">Contact Us</span>
                    <div className="absolute inset-0 bg-brand-red transform scale-x-0 group-hover:scale-x-100 transition-transform origin-left duration-300 ease-out" />
                 </button>
              </div>

              <div className="space-y-4">
                {['HHMZ Dance School', 'Gallery', 'Story', 'Shop', 'Adventures', 'Services'].map((item, idx) => (
                    <a key={item} href="#" className={`block text-xs font-bold tracking-[0.15em] uppercase hover:text-brand-red transition-colors ${idx === 0 ? 'text-brand-red mb-6' : 'text-gray-400'}`}>
                        {item}
                    </a>
                ))}
              </div>
            </div>

            <div className="mt-16 flex gap-6">
                <a href="#" className="text-brand-red hover:text-white transition-colors"><Facebook size={18} /></a>
                <a href="#" className="text-brand-red hover:text-white transition-colors"><Instagram size={18} /></a>
                <a href="#" className="text-brand-red hover:text-white transition-colors"><Youtube size={18} /></a>
            </div>
          </div>

          {/* Right Column: Map */}
          <div className="flex-[2] h-[300px] md:h-[400px] w-full bg-gray-900 rounded-sm overflow-hidden relative group">
            <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d114584.77026569766!2d27.94276135688694!3d-26.171453272023587!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1e950c68f0406a51%3A0x238ac9d9b1d34041!2sJohannesburg%2C%20South%20Africa!5e0!3m2!1sen!2sus!4v1714420000000!5m2!1sen!2sus" 
                width="100%" 
                height="100%" 
                style={{border:0, filter: 'grayscale(100%) invert(90%) contrast(85%)'}} 
                allowFullScreen={true} 
                loading="lazy" 
                referrerPolicy="no-referrer-when-downgrade"
                className="group-hover:filter-none transition-all duration-500"
            ></iframe>
            
            {/* Map Overlay Card */}
            <div className="absolute top-4 left-4 bg-white text-black p-4 shadow-lg max-w-[200px]">
                <div className="flex items-start gap-2">
                    <MapPin size={16} className="text-brand-red mt-1 shrink-0" />
                    <div>
                        <p className="text-[10px] font-bold uppercase tracking-wide leading-tight">25°58'56.9"S 28°00'53.8"E</p>
                        <p className="text-[10px] text-gray-500 mt-1">2297+2X8 Sandton</p>
                        <a href="#" className="text-[10px] text-blue-600 mt-1 block hover:underline">View larger map</a>
                    </div>
                </div>
            </div>

             <div className="absolute bottom-4 right-4 text-[10px] text-black font-bold opacity-50">
                MADE BY <span className="font-black">HEXWEB</span>
            </div>
          </div>

        </div>
      </div>
    </footer>
  );
};

export default Footer;