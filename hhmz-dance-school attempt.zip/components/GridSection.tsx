import React from 'react';
import { motion } from 'framer-motion';
import { MoveRight } from 'lucide-react';
import { GridItem } from '../types';

const items: GridItem[] = [
  {
    id: 1,
    title: 'HHMZ Dance School',
    subtitle: 'The Best Dancer \'24',
    imageUrl: 'https://images.unsplash.com/photo-1504609773096-104ff2c73ba4?q=80&w=2670&auto=format&fit=crop',
    size: 'regular',
  },
  {
    id: 2,
    title: 'Gallery',
    subtitle: 'The Success Stories',
    imageUrl: 'https://images.unsplash.com/photo-1516280440614-6697288d5d38?q=80&w=2670&auto=format&fit=crop',
    size: 'regular',
  },
  {
    id: 3,
    title: 'Achievements',
    subtitle: 'The Success Stories',
    imageUrl: 'https://images.unsplash.com/photo-1535525153412-5a42439a210d?q=80&w=2670&auto=format&fit=crop',
    size: 'regular',
  },
  {
    id: 4,
    title: 'Clients',
    subtitle: 'Supported Schools',
    imageUrl: 'https://images.unsplash.com/photo-1571210862729-78a52d3779a2?q=80&w=2670&auto=format&fit=crop',
    size: 'regular',
  },
];

const Card: React.FC<{ item: GridItem; index: number }> = ({ item, index }) => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }}
      viewport={{ once: true, margin: "-10%" }}
      transition={{ duration: 0.8, delay: index * 0.1, ease: [0.22, 1, 0.36, 1] }}
      className="relative group overflow-hidden w-full h-[50vh] bg-gray-900 cursor-pointer border border-white/5"
    >
      {/* Image with zoom on hover */}
      <motion.img
        src={item.imageUrl}
        alt={item.title}
        className="w-full h-full object-cover transition-transform duration-[1.2s] ease-[cubic-bezier(0.25,1,0.5,1)] group-hover:scale-105"
      />
      
      {/* Overlay */}
      <div className="absolute inset-0 bg-black/40 transition-opacity duration-500 group-hover:opacity-30" />
      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-80" />

      {/* Content */}
      <div className="absolute inset-0 p-6 md:p-10 flex flex-col justify-end">
        <div className="overflow-hidden mb-2">
            {item.subtitle && (
                <span className="block text-xs md:text-sm font-bold tracking-[0.2em] text-brand-red uppercase transform translate-y-full transition-transform duration-500 delay-100 group-hover:translate-y-0">
                    {item.subtitle}
                </span>
            )}
        </div>
        
        <div className="flex items-end justify-between gap-4 overflow-hidden">
            <h3 className="font-display font-medium text-4xl md:text-5xl lg:text-6xl text-white leading-none tracking-tight transform transition-transform duration-500 group-hover:-translate-y-2">
            {item.title}
            </h3>
            <span className="text-white mb-2 opacity-0 translate-y-4 -translate-x-4 transition-all duration-500 group-hover:opacity-100 group-hover:translate-y-0 group-hover:translate-x-0">
                 <MoveRight size={40} strokeWidth={1.5} />
            </span>
        </div>
      </div>
    </motion.div>
  );
};

const GridSection: React.FC = () => {
  return (
    <section className="bg-black py-0 w-full">
      <div className="grid grid-cols-1 md:grid-cols-2 w-full">
        {items.map((item, idx) => (
          <Card key={item.id} item={item} index={idx} />
        ))}
      </div>
    </section>
  );
};

export default GridSection;