import React, { useEffect } from 'react';
import Lenis from '@studio-freight/lenis';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import GridSection from './components/GridSection';
import Footer from './components/Footer';
import NoiseOverlay from './components/NoiseOverlay';

const App: React.FC = () => {
  useEffect(() => {
    // Initialize Smooth Scrolling
    const lenis = new Lenis({
      duration: 1.2,
      easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      orientation: 'vertical',
      gestureOrientation: 'vertical',
      smoothWheel: true,
    });

    function raf(time: number) {
      lenis.raf(time);
      requestAnimationFrame(raf);
    }

    requestAnimationFrame(raf);

    return () => {
      lenis.destroy();
    };
  }, []);

  return (
    <div className="min-h-screen w-full bg-black relative">
      <NoiseOverlay />
      <Navbar />
      
      <main className="relative z-10">
        <Hero />
        <GridSection />
      </main>
      
      <Footer />
    </div>
  );
};

export default App;