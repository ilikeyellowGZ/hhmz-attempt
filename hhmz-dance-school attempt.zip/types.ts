import React from 'react';

export interface NavLink {
  label: string;
  href: string;
  isSpecial?: boolean;
}

export interface GridItem {
  id: number;
  title: string;
  subtitle?: string;
  imageUrl: string;
  linkText?: string;
  size: 'regular' | 'wide';
}

export interface SocialLink {
  icon: React.ElementType;
  href: string;
}