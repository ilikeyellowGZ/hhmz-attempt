import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import HeroCarousel from '../components/HeroCarousel';
import { HERO_IMAGES, STAFF } from '../constants';

const Profile: React.FC = () => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen bg-brand-black text-white"
    >
      <HeroCarousel 
        images={[...HERO_IMAGES].reverse()} 
        title="HHMZ Dance Family"
      />

      {/* Our Story Section */}
      <section className="max-w-7xl mx-auto px-6 py-24">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
          <Link to="/gallery" className="relative group overflow-hidden block">
            <motion.img 
              whileHover={{ scale: 1.03 }}
              transition={{ duration: 0.5 }}
              src="https://picsum.photos/seed/story/800/600" 
              alt="Our Story" 
              className="w-full h-auto object-cover grayscale group-hover:grayscale-0 transition-all duration-500"
            />
            <div className="absolute bottom-4 left-4 text-white opacity-0 group-hover:opacity-100 transition-opacity">
              <span className="text-sm font-bold tracking-widest">SEE MORE HHMZ &rarr;</span>
            </div>
          </Link>

          <div className="space-y-12">
            <div>
              <h2 className="text-2xl font-bold mb-6">Our story</h2>
              <p className="font-light leading-loose text-white/80 text-sm md:text-base">
                This studio started from a simple idea: dance should feel real. What began as freestyles, cyphers, and late-night rehearsals turned into a space where dancers could train, grow, and belong. 
                <br /><br />
                We built this place for the ones who move different. For the dancers who use movement as a voice, a release, and a lifestyle. Today, we're more than a studio — we're a movement, a family, and a culture.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold mb-6">About the Studio</h2>
              <p className="font-light leading-loose text-white/80 text-sm md:text-base">
                We're an urban dance studio built on rhythm, culture, and community. Our classes are open to all ages and levels, but the energy stays the same — real, focused, and unapologetic.
                <br /><br />
                Our instructors bring street knowledge, performance experience, and passion into every session. We push technique, musicality, and individuality, while keeping the vibe supportive and motivating. No pressure to be perfect — just come ready to work and express.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Staff Section */}
      <section className="max-w-7xl mx-auto px-6 pb-24">
        <h2 className="text-3xl font-bold mb-12">Employed Staff</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {STAFF.map((staff) => (
            <div key={staff.id} className="group">
              <div className="overflow-hidden mb-6 relative aspect-[3/4]">
                <img 
                  src={staff.image} 
                  alt={staff.name} 
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 grayscale group-hover:grayscale-0"
                />
              </div>
              <div className="space-y-1">
                <p className="text-[10px] text-brand-red font-bold uppercase tracking-widest mb-2">{staff.role}</p>
                <h3 className="text-xl font-bold">{staff.name}</h3>
                <p className="text-[10px] text-white/50 uppercase tracking-wider mt-2">
                  {staff.tags.join(' • ')}
                </p>
                <div className="w-full h-[1px] bg-brand-red/30 mt-4 group-hover:bg-brand-red transition-colors" />
              </div>
            </div>
          ))}
        </div>
      </section>
    </motion.div>
  );
};

export default Profile;