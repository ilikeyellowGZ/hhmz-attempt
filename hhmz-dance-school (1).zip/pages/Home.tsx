import React from 'react';
import { motion } from 'framer-motion';
import HeroCarousel from '../components/HeroCarousel';
import GridTile from '../components/GridTile';
import { HERO_IMAGES } from '../constants';

const Home: React.FC = () => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
      className="min-h-screen bg-brand-black"
    >
      <HeroCarousel 
        images={HERO_IMAGES} 
        title="HHMZ Dance Family" 
      />

      <div className="max-w-7xl mx-auto px-4 md:px-6 py-12 md:py-24">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
          {/* Main big tile - Link to Company Profile */}
          <GridTile 
            to="/profile"
            image="https://picsum.photos/seed/home1/1200/800"
            title="HHMZ Dance School"
            subtitle="The Best Dancer '24"
            large
          />

          {/* Gallery Link */}
          <GridTile 
            to="/gallery"
            image="https://picsum.photos/seed/home2/600/800"
            title="Gallery"
            subtitle="The Success Stories"
          />

          {/* Achievements Link */}
          <GridTile 
            to="/profile"
            image="https://picsum.photos/seed/home3/600/800"
            title="Achievements"
            subtitle="The Success Stories"
          />

           {/* Clients Link - Full Width */}
           <GridTile 
            to="/profile"
            image="https://picsum.photos/seed/home4/1200/600"
            title="Clients"
            subtitle="Supported Schools"
            large
          />
        </div>
      </div>
    </motion.div>
  );
};

export default Home;