import React from 'react';
import { motion } from 'framer-motion';
import HeroCarousel from '../components/HeroCarousel';
import { PRODUCTS, HERO_IMAGES } from '../constants';

const Shop: React.FC = () => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen bg-brand-black text-white"
    >
      <HeroCarousel 
        images={[HERO_IMAGES[2], HERO_IMAGES[4], HERO_IMAGES[0], HERO_IMAGES[1], HERO_IMAGES[3]]} 
        title="HHMZ Dance Family"
        overlay
      />

      <section className="max-w-7xl mx-auto px-6 py-24">
        <h2 className="text-sm font-bold tracking-widest uppercase mb-12">Shop</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-16">
          {PRODUCTS.map((product) => (
            <motion.div 
              key={product.id} 
              className="group cursor-pointer"
              whileHover={{ y: -10 }}
              transition={{ type: 'spring', stiffness: 300 }}
            >
              <div className="bg-white p-8 aspect-square flex items-center justify-center mb-6 relative overflow-hidden">
                <img 
                  src={product.image} 
                  alt={product.name} 
                  className="w-full h-full object-contain mix-blend-multiply transition-transform duration-500 group-hover:scale-110" 
                />
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/5 transition-colors duration-300" />
              </div>
              
              <div className="space-y-1">
                <h3 className="text-lg font-light text-white">{product.name}</h3>
                <p className="text-sm text-white/60">R{product.price.toFixed(2)}</p>
                <p className="text-[9px] text-white/40 uppercase tracking-widest mt-2">All purchase to be made in store</p>
              </div>
            </motion.div>
          ))}
        </div>
      </section>
    </motion.div>
  );
};

export default Shop;