import React from 'react';
import { motion } from 'framer-motion';

const Contact: React.FC = () => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen bg-brand-black text-white pt-32"
    >
      <div className="max-w-7xl mx-auto px-6 pb-12">
        <h1 className="text-5xl font-bold mb-12">Get in touch</h1>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div className="space-y-8">
            <div>
              <h3 className="text-brand-red text-xs font-bold uppercase tracking-widest mb-2">Visit Us</h3>
              <p className="text-xl font-light">2297+2X8 Sandton<br />Junction Church<br />Johannesburg</p>
            </div>
            
            <div>
              <h3 className="text-brand-red text-xs font-bold uppercase tracking-widest mb-2">Email</h3>
              <a href="mailto:info@hhmz.co.za" className="text-xl font-light hover:text-brand-red transition-colors">info@hhmz.co.za</a>
            </div>

            <div>
              <h3 className="text-brand-red text-xs font-bold uppercase tracking-widest mb-2">Phone</h3>
              <a href="tel:+27123456789" className="text-xl font-light hover:text-brand-red transition-colors">+27 12 345 6789</a>
            </div>
          </div>

          <div className="h-[400px] bg-white/5 rounded-lg overflow-hidden relative grayscale invert-[0.1]">
             {/* Simple static map placeholder as requested for minimal distraction, in real app would be Google Maps Iframe */}
             <img 
              src="https://picsum.photos/seed/map/800/600" 
              alt="Map"
              className="w-full h-full object-cover opacity-70" 
             />
             <div className="absolute inset-0 flex items-center justify-center">
                <div className="bg-brand-red p-3 rounded-full shadow-lg shadow-brand-red/50 animate-bounce">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                  </svg>
                </div>
             </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default Contact;