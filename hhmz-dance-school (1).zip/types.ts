export interface NavLink {
  label: string;
  path: string;
}

export interface Product {
  id: string;
  name: string;
  price: number;
  category: 't-shirt' | 'hoodie' | 'shorts';
  image: string;
}

export interface StaffMember {
  id: string;
  name: string;
  role: string;
  image: string;
  tags: string[];
}

export interface GalleryImage {
  id: string;
  src: string;
  alt: string;
  span?: boolean;
}