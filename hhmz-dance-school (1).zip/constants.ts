import { NavLink, Product, StaffMember, GalleryImage } from './types';

export const NAV_LINKS: NavLink[] = [
  { label: 'Story', path: '/profile' },
  { label: 'Services', path: '/profile' }, // Mapping clients/services to profile as per prompt
  { label: 'Adventures', path: '/gallery' },
  { label: 'Shop', path: '/shop' },
  { label: 'Contact', path: '/contact' },
];

export const STAFF: StaffMember[] = [
  {
    id: '1',
    name: 'Henry Nene',
    role: 'Dance Instructor',
    image: 'https://picsum.photos/seed/dance1/400/600',
    tags: ['Amapiano', 'Urban', 'Pop', 'Hip Hop']
  },
  {
    id: '2',
    name: 'Lerato Nene',
    role: 'Dance Instructor',
    image: 'https://picsum.photos/seed/dance2/400/600',
    tags: ['Amapiano', 'Urban', 'Pop', 'Hip Hop']
  },
  {
    id: '3',
    name: 'Michael James',
    role: 'Senior Choreographer',
    image: 'https://picsum.photos/seed/dance3/400/600',
    tags: ['Krump', 'Street', 'Technical']
  }
];

export const PRODUCTS: Product[] = [
  {
    id: 'p1',
    name: 'HHMZ T-shirt',
    price: 150.00,
    category: 't-shirt',
    image: 'https://picsum.photos/seed/shirt1/500/500'
  },
  {
    id: 'p2',
    name: 'HHMZ Hoodie',
    price: 1050.00,
    category: 'hoodie',
    image: 'https://picsum.photos/seed/hoodie1/500/500'
  },
  {
    id: 'p3',
    name: 'HHMZ Short Pants',
    price: 150.00,
    category: 'shorts',
    image: 'https://picsum.photos/seed/shorts1/500/500'
  },
  {
    id: 'p4',
    name: 'HHMZ T-shirt (Navy)',
    price: 150.00,
    category: 't-shirt',
    image: 'https://picsum.photos/seed/shirt2/500/500'
  },
   {
    id: 'p5',
    name: 'HHMZ Hoodie (Black)',
    price: 1050.00,
    category: 'hoodie',
    image: 'https://picsum.photos/seed/hoodie2/500/500'
  }
];

export const GALLERY_IMAGES: GalleryImage[] = [
  { id: 'g1', src: 'https://picsum.photos/seed/gal1/800/600', alt: 'Dance Crew 1', span: true },
  { id: 'g2', src: 'https://picsum.photos/seed/gal2/400/600', alt: 'Dance Solo' },
  { id: 'g3', src: 'https://picsum.photos/seed/gal3/400/400', alt: 'Rehearsal' },
  { id: 'g4', src: 'https://picsum.photos/seed/gal4/400/400', alt: 'Competition' },
  { id: 'g5', src: 'https://picsum.photos/seed/gal5/400/600', alt: 'Backstage' },
  { id: 'g6', src: 'https://picsum.photos/seed/gal6/800/400', alt: 'Group Shot', span: true },
];

export const HERO_IMAGES = [
  'https://picsum.photos/seed/hero1/1920/1080',
  'https://picsum.photos/seed/hero2/1920/1080',
  'https://picsum.photos/seed/hero3/1920/1080',
  'https://picsum.photos/seed/hero4/1920/1080',
  'https://picsum.photos/seed/hero5/1920/1080',
];