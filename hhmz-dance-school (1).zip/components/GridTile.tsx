import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

interface GridTileProps {
  to: string;
  image: string;
  title: string;
  subtitle?: string;
  large?: boolean;
}

const GridTile: React.FC<GridTileProps> = ({ to, image, title, subtitle, large = false }) => {
  return (
    <Link to={to} className={`relative block overflow-hidden group ${large ? 'col-span-1 md:col-span-2' : 'col-span-1'}`}>
      <div className={`relative w-full ${large ? 'h-[500px]' : 'h-[350px] md:h-[500px]'}`}>
        <motion.img
          whileHover={{ scale: 1.05 }}
          transition={{ duration: 0.6 }}
          src={image}
          alt={title}
          className="absolute inset-0 w-full h-full object-cover transition-transform duration-700"
        />
        <div className="absolute inset-0 bg-black/30 group-hover:bg-black/10 transition-colors duration-500" />
        <div className="absolute bottom-0 left-0 p-8 w-full bg-gradient-to-t from-black/80 to-transparent">
          {subtitle && (
             <p className="text-[10px] font-bold tracking-[0.2em] uppercase text-white/70 mb-2">{subtitle}</p>
          )}
          <div className="flex items-center space-x-2 group">
            <h3 className="text-2xl md:text-3xl font-bold text-white tracking-tight">{title}</h3>
             <motion.span 
              className="text-brand-red text-2xl"
              initial={{ x: 0 }}
              whileHover={{ x: 10 }}
             >
               &rarr;
             </motion.span>
          </div>
        </div>
      </div>
    </Link>
  );
};

export default GridTile;