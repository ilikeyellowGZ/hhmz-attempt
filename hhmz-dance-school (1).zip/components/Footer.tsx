import React from 'react';
import { Link } from 'react-router-dom';
import { NAV_LINKS } from '../constants';

const Footer: React.FC = () => {
  return (
    <footer className="relative w-full bg-brand-black border-t border-white/10 mt-12">
      <div className="grid grid-cols-1 lg:grid-cols-2 h-auto lg:h-[400px]">
        {/* Left: Contact Info */}
        <div className="p-12 flex flex-col justify-between relative z-10 bg-brand-black/95">
          <div className="mb-12">
            <Link to="/contact" className="inline-block border border-brand-red text-white text-xs font-bold px-8 py-3 tracking-[0.2em] hover:bg-brand-red transition-colors duration-300">
              CONTACT US
            </Link>
          </div>

          <div className="space-y-6">
            <div className="flex flex-col space-y-2">
              <h4 className="text-brand-red text-[10px] font-bold tracking-widest uppercase mb-2">Navigation</h4>
              {NAV_LINKS.map(link => (
                <Link key={link.label} to={link.path} className="text-white/60 text-[10px] tracking-widest uppercase hover:text-white transition-colors w-fit">
                  {link.label}
                </Link>
              ))}
            </div>
            
            <div className="pt-8 flex items-center space-x-4">
              {/* Social Icons Placeholder */}
              <div className="w-3 h-3 bg-brand-red rounded-full"></div>
              <div className="w-3 h-3 bg-white/20 rounded-full hover:bg-brand-red transition-colors"></div>
              <div className="w-3 h-3 bg-white/20 rounded-full hover:bg-brand-red transition-colors"></div>
              <div className="w-3 h-3 bg-white/20 rounded-full hover:bg-brand-red transition-colors"></div>
            </div>
          </div>
        </div>

        {/* Right: Map Visual */}
        <div className="relative h-[300px] lg:h-full overflow-hidden grayscale invert-[0.1]">
          <img 
            src="https://picsum.photos/seed/map/800/400" 
            alt="Location Map" 
            className="w-full h-full object-cover opacity-60"
          />
          <div className="absolute inset-0 bg-gradient-to-l from-transparent to-brand-black/80 lg:to-brand-black/20"></div>
          
          <div className="absolute bottom-4 right-4 bg-white/90 p-4 rounded text-black text-[10px]">
            <p className="font-bold">25°58'56.9"S 28°00'53.8"E</p>
            <p>2297+2X8 Sandton</p>
            <span className="text-blue-600 underline cursor-pointer">View larger map</span>
          </div>
        </div>
      </div>
      
      <div className="bg-black py-4 px-12 flex justify-between items-center border-t border-white/5">
        <p className="text-[9px] text-white/30 uppercase tracking-widest">© 2025 HHMZ Dance School</p>
        <p className="text-[9px] text-white/30 uppercase tracking-widest">Made by HeyWebb</p>
      </div>
    </footer>
  );
};

export default Footer;